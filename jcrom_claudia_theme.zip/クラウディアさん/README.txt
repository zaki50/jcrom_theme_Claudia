JCROM 用のクラウディアさんテーマです。

以下のライセンスに従って配布を行なっています。
このテーマ自体は Apache License 2.0 で公開しますが、使用している音声や画像データは以下のライセンスに従う必要があります。

このテーマを元に派生テーマを作る際は、以下のライセンスに従ってください。

Windows Azure キャラクターライセンス
http://msdn.microsoft.com/ja-jp/windowsazure/hh298798#06

Windows Azure 公認キャラクター利用ガイドライン(解説集)
http://msdn.microsoft.com/ja-jp/windowsazure/hh298798

